/*Template for p5 Play library
Kushal and Maxim - May 2021
This file shows an example for a sprite with an image*/

//We are assigning this sprite to a variable name, so that we can change its properties

var rbcl1; //Rainbow Cloud during lvl 0 and ending screen
var rbcl2; //Rainbow Cloud during the game
var rbcl1Image;
var rbcl2Image;
var cloud; //Clouds that drop snowflakes
var cloudImage;
//https://www.vippng.com/preview/bmoTT_valley-and-clouds-clip-art-cliparts-transparent-background/
// Snowflakes are obstacles to avoid
var snowflkImage;
var snowflk; //Snow flake on the left cloud
var snowflk1; //snow flake on the right cloud

//http://clipart-library.com/clipart/1466649.htm
var hotBalloon1; //balloons (obstacles to avoid)
var hotBalloon1Image;
var hotBalloon2;
var hotBalloon2Image;
//http://clipart-library.com/free/balloon-vector-png.html (for both balloons)
var potOfGold; //final gold
//http://clipart-library.com/free/transparent-pot-of-gold.html
var potOfGoldImage;
var star; //Star at the end of each level
var starImage;
var rainbow;//rainbow (purely cosmetic)
var rainbowImage;
var timer = 0; //timer to see how fast you beat the level


//https://www.pngkey.com/download/u2q8u2q8w7y3q8a9_30-cartoon-rainbow-png-rainbow-clipart/
var level = 0;
//https://www.clipartkey.com/downpng/mhJhJw_simple-star-coloring-page/
function preload() {
  //this image is being preloaded using the preload() 
  //function. This will allow it to load fully before the program begins.

  rbcl1Image = loadImage('rainbowCloud1.png');
  rbcl2Image = loadImage('rainbowCloud2.png')
  cloudImage = loadImage('cloud.png');
  cloud1Image = loadImage('cloud.png')
  snowflkImage = loadImage('snowflake.png');
  snowflk1Image = loadImage('snowflake.png')
  hotBalloon1Image = loadImage('hotAirBalloon1.png');
  hotBalloon2Image = loadImage('hotAirBalloon2.png');
  hotBalloon3Image = loadImage('hotAirBalloon1.png');
  hotBalloon4Image = loadImage('hotAirBalloon2.png')
  potOfGoldImage = loadImage('goldPot.png');
  starImage = loadImage('goldStar.png');
  rainbowImage = loadImage('rainbow.png');



}

function setup() {
  //creating a canvas
  createCanvas(800, 600);

  //resizing everything to appropriate sizes

  rbcl1Image.resize(400, 400);
  rbcl2Image.resize(100, 100);
  cloudImage.resize(150, 100);
  cloud1Image.resize(150, 100);
  snowflkImage.resize(60, 60);
  snowflk1Image.resize(100, 100);
  hotBalloon1Image.resize(90, 130);
  hotBalloon2Image.resize(90, 130);
  hotBalloon3Image.resize(90, 130);
  hotBalloon4Image.resize(90, 130);
  potOfGoldImage.resize(300, 300);
  starImage.resize(200, 200);
  rainbowImage.resize(800, 300);

  //placing them on the screen
  rbcl1 = createSprite(width / 4, height * 3 / 4.5);
  rbcl2 = createSprite(width / 15, height / 2);
  cloud = createSprite(width * 3 / 10, height / 15);
  cloud1 = createSprite(width * 6.5 / 10, 0 + height / 15);
  snowflk = createSprite(random(width * 3 / 10 - 75, 0 + height / 15), random(width * 3 / 10 + 75, 0 + height / 15));
  snowflk.velocity.y = 10
  snowflk1 = createSprite(random(width * 6.5 / 10 - 75, 0 + height / 15), random(width * 6.5 / 10 + 75, 0 + height / 15));
  snowflk1.velocity.y = 10
  hotBalloon1 = createSprite(width / 5 + width / 25, height / 5);
  hotBalloon2 = createSprite(width * 6.5 / 7, height * 0.5 / 4);
  hotBalloon3 = createSprite(width * 4.2 / 7, height * 2.35 / 4);
  hotBalloon4 = createSprite(width * 3 / 7, height * 3.25 / 4);
  potOfGold = createSprite(width * 3.25 / 4, height - height / 4);
  star = createSprite(width * 3 / 4, height / 1.5);
  rainbow = createSprite(width / 2, height / 17);
  //assigning the images 
  rbcl1.addImage(rbcl1Image);
  rbcl2.addImage(rbcl2Image);
  cloud.addImage(cloudImage);
  cloud1.addImage(cloudImage);
  snowflk.addImage(snowflkImage);
  snowflk1.addImage(snowflkImage);
  hotBalloon1.addImage(hotBalloon1Image);
  hotBalloon2.addImage(hotBalloon2Image);
  hotBalloon3.addImage(hotBalloon1Image);
  hotBalloon4.addImage(hotBalloon2Image);
  potOfGold.addImage(potOfGoldImage);
  star.addImage(starImage);
  rainbow.addImage(rainbowImage);

}

function draw() {
  background(0, 191, 255);

  if (level === 0) {

    // the box for the text
    rect(width / 20, height / 7, width - width / 10, height / 5)
    fill("black")
    textAlign(CENTER, CENTER);
    textSize(28);
    strokeWeight(3);
    textFont('Georgia');
    //the actual text

    text("Hey, I'm Rainbow Cloud and I'm a gold hunter.\n I heard there was a pot of gold at the end of this rainbow. \n Press enter to start the journey!", width / 2, height / 4);
    //drawing rainbow cloud, the star and the rainbow
    drawSprite(rbcl1);
    drawSprite(star);
    drawSprite(rainbow);




  }
  else if (level === 1) {
    //balloons
    clear();
    background(0, 191, 255);
    //Start the timer here
    timer += 1 / 60
    //text box
    fill("white")
    rect(width / 10, height * 5 / 6, width - width / 5, height / 6);
    fill("black");
    textAlign(CENTER, CENTER);
    textSize(28);
    strokeWeight(3);
    textFont("Georgia");
    //Text instructions at the bottom

    text("Use the arrow keys to avoid the hot air balloons \n and get Rainbow Cloud to the star!", width / 2, height * 10 / 11);
    rectMode(CENTER);
    fill("gold")
    //platform
    rect(width / 15, height * 8.5 / 15, 80, 45);
    rectMode(CORNER);
    //drawing required sprites
    drawSprite(hotBalloon1);
    drawSprite(hotBalloon2);
    drawSprite(hotBalloon3);
    drawSprite(hotBalloon4);
    drawSprite(star);
    drawSprite(rbcl2);
    drawSprite(rainbow);


  }

  else if (level === 2) {
    //snowflakes
    clear();
    background(0, 191, 255);
    timer += 1 / 60
    //text box
    fill("white")
    rect(width / 10, height * 5 / 6, width - width / 5, height / 6);
    fill("black")
    textAlign(CENTER, CENTER);
    textSize(28);
    strokeWeight(3);
    textFont("Georgia");
    //the text
    text("This time, use the arrow keys to avoid the falling \n snowflakes and get Rainbow Cloud to the star!", width / 2, height * 10 / 11);
    rectMode(CENTER);
    fill("gold")
    //platform
    rect(width / 15, height * 8.5 / 15, 80, 45);
    rectMode(CORNER)
    //Text instructioins at the bottom
    //moving around the snowflake
    if (snowflk.position.y > height) {
      snowflk.position.x = random(width * 3 / 10 - 75, width * 3 / 10 + 75);
      snowflk.position.y = 0 + height / 15
      snowflk.velocity.y = random(1.5, 2.5)
    }
    if (snowflk1.position.y > height) {
      snowflk1.position.x = random(width * 6.5 / 10 - 75, width * 6.5 / 10 + 75);
      snowflk1.position.y = 0 + height / 15
      snowflk1.velocity.y = random(1.5, 2.5)
    }

    drawSprite(cloud1);
    drawSprite(cloud);
    drawSprite(star);
    drawSprite(rbcl2);
    drawSprite(snowflk);
    drawSprite(snowflk1);
    drawSprite(rainbow);


  }
  else if (level === 3) {
    //both baloons and snowflakes
    clear();
    background(0, 191, 255);
    timer += 1 / 60
    //text box
    fill("white")
    rect(width / 10, height * 5 / 6, width - width / 5, height / 6);
    fill("black")
    textAlign(CENTER, CENTER);
    textSize(28);
    strokeWeight(3);
    textFont("Georgia");
    text("Now use the arrow keys to avoid both \n snowflakes AND the hot air balloons!", width / 2, height * 10 / 11);
    rectMode(CENTER);
    fill("gold")
    rect(width / 15, height * 8.5 / 15, 80, 45);
    rectMode(CORNER)
    //Text instructioins at the bottom


    if (snowflk.position.y > height) {
      snowflk.position.x = random(width * 3 / 10 - 75, width * 3 / 10 + 75);
      snowflk.position.y = 0 + height / 15
      snowflk.velocity.y = random(1.5, 2.5)
    }
    if (snowflk1.position.y > height) {
      snowflk1.position.x = random(width * 6.5 / 10 - 75, width * 6.5 / 10 + 75);
      snowflk1.position.y = 0 + height / 15
      snowflk1.velocity.y = random(1.5, 2.5)
    }
    //drawing all the sprites
    drawSprite(cloud1);
    drawSprite(cloud);
    drawSprite(star);
    drawSprite(rbcl2);
    drawSprite(hotBalloon1);
    drawSprite(hotBalloon2);
    drawSprite(hotBalloon3);
    drawSprite(hotBalloon4);
    drawSprite(rainbow);
    drawSprite(snowflk);
    drawSprite(snowflk1);


  }
  else if (level === 4) {
    //final level (just the end screen)
    clear();
    background(0, 191, 255);
    rect(width / 20, height / 7, width - width / 10, height / 5)
    fill("black")
    textAlign(CENTER, CENTER);
    textSize(28);
    strokeWeight(3);
    textFont('Georgia');
    text("We did it, we're rich! We found it in " + round(timer) + " seconds.\n Can we go faster next time? Click enter to play again.", width / 2, height / 4)
    drawSprite(rainbow);
    drawSprite(rbcl1)
    drawSprite(potOfGold)

  }
  //Unallowing (real word btw) Rainbow Cloud to exit the screen (self taught)
  if (0 > rbcl2.position.x) {
    rbcl2.position.x = 0
  }

  if (rbcl2.position.x > width) {
    rbcl2.position.x = width
  }
  
  if (rbcl2.position.y > height) {
    rbcl2.position.y = height
  }

  if (0 > rbcl2.position.y) {
    rbcl2.position.y = 0
  }


  //collisions and making it so when rbcl comes in contact with any of the obsticles she gets sent back right to the begining 
  if ((level === 1 || level === 3) && rbcl2.collide(hotBalloon1)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }

  if ((level === 1 || level === 3) && rbcl2.collide(hotBalloon2)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if ((level === 1 || level === 3) && rbcl2.collide(hotBalloon3)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if ((level === 1 || level === 3) && rbcl2.collide(hotBalloon4)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }

  if ((level === 2 || level === 3) && rbcl2.collide(cloud)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if ((level === 2 || level === 3) && rbcl2.collide(cloud1)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if ((level === 2 || level === 3) && rbcl2.collide(snowflk)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if ((level === 2 || level === 3) && rbcl2.collide(snowflk1)) {
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }


  //arrowkeys to move rbcl
  if (keyIsDown(LEFT_ARROW)) {
    rbcl2.position.x = rbcl2.position.x - 5
    //Right arrow makes you go to the right
  } else if (keyIsDown(RIGHT_ARROW)) {
    rbcl2.position.x = rbcl2.position.x + 5
    //Down arrow makes you go down
  } else if (keyIsDown(DOWN_ARROW)) {
    rbcl2.position.y = rbcl2.position.y + 5
    //Up arrow makes you go up
  } else if (keyIsDown(UP_ARROW)) {
    rbcl2.position.y = rbcl2.position.y - 5
  }
}


function keyPressed() {
  //if you press enter, you go to next level
  if (level === 0 && keyCode === ENTER) {
    level = 1
    //moving around the star and rbcl2
    star.position.x = width * 9 / 10
    star.position.y = height / 2
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
    //smaller star
    star.scale = 0.2
  }
  if (level === 1 && rbcl2.collide(star)) {
    //when the requirements are met, you go to level 2
    level = 2
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
    //moving rbcl back
  }

  //to the next level
  if (level === 2 && rbcl2.collide(star)) {
    level = 3
    rbcl2.position.x = width / 15
    rbcl2.position.y = height / 2
  }
  if (level === 3 && rbcl2.collide(star)) {
    level = 4
  }
  if (level === 4 && keyCode === ENTER) {
    //final level, if you press enter, you restart.
    level = 0
    star.position.x = width * 3 / 4
    star.position.y = height / 1.5
    star.scale = 1
    //reposition 
    timer = 0
    //reset the timer
  }
}
